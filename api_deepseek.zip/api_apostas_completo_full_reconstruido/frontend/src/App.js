import React from "react";
import PainelApostas from "./PainelApostas";

function App() {
  return (
    <div>
      <PainelApostas />
    </div>
  );
}

export default App;